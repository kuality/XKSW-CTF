# [Easy] easy-login

## Description
A simple login form.

Can you bypass the login logic and reveal the flag?
