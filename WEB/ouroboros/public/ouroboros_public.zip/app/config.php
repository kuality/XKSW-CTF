<?php 

$conn = new mysqli("ouroboros-mysql", "xksw", "xksw", "user");
$flag = "XKSW{this_is_fake_flag}";

?>