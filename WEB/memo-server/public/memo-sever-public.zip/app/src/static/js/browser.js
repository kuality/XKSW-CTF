var browser = {
	"useragent":window.navigator.userAgent.toLowerCase(),
	"ChromeDownloadURL":"https://www.google.com/intl/ko/chrome/"
}
console.log(browser.useragent);