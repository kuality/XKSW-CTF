<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>F학점 경고</title>
</head>
<body style="text-align:center; background-color: #fce4e4;">
    <h1>자네 지금 뭘 하는가...</h1>
    <h2>자네는 F일세.</h2>
    <img src="youf.png" alt="F 이미지" width="300">
</body>
</html>

