qemu-mips-static ./prob
